'''lista02_q08'''


def main():
    lista = ['a', 'e', 'x', 'a', f'', 'h', 's', 'a', 'a', 'y', 'm', 'h', 'a', 't', 'q', 'b', 'a', 'j', 'r', 'a', 'v',
             'b', 'a', 'p', 'a']

    print(f'A lista é {lista}.')
    print(f'A letra \'a\' aparece {lista.count("a")} vezes.')


if __name__ == '__main__':
    main()
