def triangulares(a):
    for c in range(0, a):
        if c * (c + 1) * (c + 2) == a:
            return True

    return False


def main():
    num = int(input('Digite um número inteiro e maior que zero:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    resposta = triangulares(num)

    if resposta is True:
        print(f'O número {num} é triangular.')
    else:
        print(f'O número {num} não é triangular.')


if __name__ == '__main__':
    main()
