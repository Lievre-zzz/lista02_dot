'''lista02_q14'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(-20, 20))

    return a


def modificar(a, b):
    for c in a:
        if c < 0:
            b.append(0)
        else:
            b.append(c)

    return b


def main():
    lista = []
    lista_modificada = []
    lista = aleatorio(lista)
    lista_modificada = modificar(lista, lista_modificada)

    print(f'A lista é {lista}.')
    print(f'A lista modificada é {lista_modificada}.')


if __name__ == '__main__':
    main()
