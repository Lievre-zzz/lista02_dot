'''lista02_q06'''
from random import randint


def aleatorio(a, b):
    for c in range(0, 20):
        a.append(randint(1, 20))
        b.append(randint(20, 100))

    return a, b


def faturamento(a, b, c):
    for cont in range(0, 20):
        c.append(a[cont] * b[cont])

    return c


def abaixodamedia(a, b):
    aaa = []

    for pos, c in enumerate(a):
        if c < b:
            aaa.append(pos)

    return aaa


def main():
    quantidades = []
    precos = []
    faturamentoporproduto = []
    quantidades, precos = aleatorio(quantidades, precos)
    faturamentoporproduto = faturamento(quantidades, precos, faturamentoporproduto)
    faturamentototal = sum(faturamentoporproduto)
    mediafaturamento = faturamentototal / len(faturamentoporproduto)
    fatabaixodamedia = abaixodamedia(faturamentoporproduto, mediafaturamento)

    print(f'A quantidade de cada um dos 20 produtos da loja está representada na seguinte lista: {quantidades}.')
    print(f'O preço, em reais, de cada um dos 20 produtos da loja está representado na seguinte lista: {precos}.')
    print(f'O faturamento estimado para cada um dos 20 produtos da loja está representado na seguinte lista: {faturamentoporproduto}.')
    print(f'O faturamento total estimado de todos os produtos da loja é de R$ {faturamentototal}.')
    print(f'A média de faturamento por produto é de R$ {mediafaturamento}.')
    print(f'Os produtos cujo faturamento estão abaixo da média são os produtos das posições {fatabaixodamedia}.')


if __name__ == '__main__':
    main()


