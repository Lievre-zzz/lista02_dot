print('marcelo flavio' == 'marcelo isaias')

'''lista02_q09'''
from random import randint


def main():



if __name__ == '__main__':
    main()
