lista = [1, 2, 3, 4, 5, 4, 5, 4, 3, 2, 5, 4, 1]
inverso = []

c = lista.index(max(lista))

print(lista.count(5))

'''lista02_q09'''
from random import randint


def main():



if __name__ == '__main__':
    main()
