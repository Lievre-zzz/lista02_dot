'''lista02_q07'''


def main():
    lista = [1, 6, 9, 13, 17, 19, 23, 27, 41, 47]

    num = int(input('Digite um número inteiro qualquer: \n'))

    print(f'A lista é {lista}.')

    if num in lista:
        print(f'O número digitado se encontra na posição {lista.index(num)} da lista.')
    else:
        print(f'O número digitado não se encontra na lista.')


if __name__ == '__main__':
    main()








