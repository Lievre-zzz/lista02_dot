def fibonacci(a):
    lista = []

    for c in range(0, a):
        if c == 0:
            lista.append(1)
        elif c == 1:
            lista.append(1)
        else:
            lista.append(lista[len(lista) - 1] + lista[len(lista) - 2])

    return lista


def main():
    num = int(input('Digite um número inteiro maior do que zero:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    sequencia = fibonacci(num)

    print(f'O {num} termo da sequência de Fibonacci é {sequencia[num - 1]}.')


if __name__ == '__main__':
    main()
