'''lista02_q18: Ler uma lista X de 10 elementos. A seguir copiar todos os valores negativos da lista X para
uma lista R, sem deixar elementos vazios entre os valores copiados. Escrever as listas X e R.'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(-20, 20))

    return a


def valneg(a, b):
    deletar = []
    subtrator = 0

    for pos, c in enumerate(a):
        if c < 0:
            b.append(c)
            deletar.append(pos)
        else:
            continue

    for c in deletar:
        a.remove(a[c - subtrator])
        subtrator += 1

    return a, b


def main():
    lista = []
    lista_negativos = []
    lista = aleatorio(lista)

    print(f'A lista antes de qualquer modificação é {lista}.')

    lista, lista_negativos = valneg(lista, lista_negativos)

    print(f'A lista após as modificações é {lista}.')
    print(f'A lista de números negativos é {lista_negativos}.')


if __name__ == '__main__':
    main()
