'''lista02_q09: Dada uma lista X numérica contendo 5 elementos, fazer um programa que crie e exiba na tela
uma lista Y. A lista Y deverá conter o mesmo conteúdo da lista X na ordem inversa.'''
from random import randint


def aleatorio(a):
    for c in range(0, 5):
        a.append(randint(0, 100))

    return a


def inverter(a, b):
    for c in a:
        b.insert(0, c)

    return b


def main():
    lista = []
    lista_invertida = []
    lista = aleatorio(lista)
    lista_invertida = inverter(lista, lista_invertida)

    print(f'A lista é {lista}.')
    print(f'A lista invertida é {lista_invertida}.')


if __name__ == '__main__':
    main()

