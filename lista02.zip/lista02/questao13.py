'''lista02_q13'''


def main():
    num = int(input('Quantas vezes o dado foi lançado?\n'))

    while num < 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    prob_dado = num // 6

