'''lista02_q16'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(1, 99))

    return a


def alterar(a, b):
    for pos, c in enumerate(a):
        if pos % 2 == 0:
            b.append(c / 2)
        else:
            b.append(c * 3)

    return b


def main():
    listax = []
    listay = []
    listax = aleatorio(listax)
    listay = alterar(listax, listay)

    print(f'A lista X é {listax}.')
    print(f'A lista Y é {listay}.')


if __name__ == '__main__':
    main()
