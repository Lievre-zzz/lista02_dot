'''lista02_q16: Ler uma lista X de 10 elementos inteiros e positivos. Criar uma lista Y da seguinte forma: os
elementos de Y com índice par receberão os respectivos elementos de X divididos por 2; os
elementos com índice ímpar receberão os respectivos elementos de X multiplicados por 3.
Escrever as listas X e Y.'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(1, 99))

    return a


def alterar(a, b):
    for pos, c in enumerate(a):
        if pos % 2 == 0:
            b.append(c / 2)
        else:
            b.append(c * 3)

    return b


def main():
    listax = []
    listay = []
    listax = aleatorio(listax)
    listay = alterar(listax, listay)

    print(f'A lista X é {listax}.')
    print(f'A lista Y é {listay}.')


if __name__ == '__main__':
    main()
