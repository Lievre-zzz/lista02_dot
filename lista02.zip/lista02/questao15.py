'''lista02_q15: Ler uma lista D de 10 elementos. Criar uma lista E, com todos os elementos de D na ordem
inversa, ou seja, o último elemento passará a ser o primeiro, o penúltimo será o segundo e assim
por diante. Escrever todo a lista D e todo a lista E.'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(0, 100))

    return a


def inverter(a, b):
    for c in a:
        b.insert(0, c)

    return b


def main():
    lista = []
    lista_invertida = []
    lista = aleatorio(lista)
    lista_invertida = inverter(lista, lista_invertida)

    print(f'A lista é {lista}.')
    print(f'A lista invertida é {lista_invertida}.')


if __name__ == '__main__':
    main()

