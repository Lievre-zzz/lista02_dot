'''lista02_q02'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(-20, 20))

    return a


def positivos(a):
    soma_positivos = 0

    for c in a:
        if c > 0:
            soma_positivos += c

    return soma_positivos


def negativos(a):
    qtd_negativos = 0

    for c in a:
        if c < 0:
            qtd_negativos += 1

    return qtd_negativos


def main():
    lista = []
    lista = aleatorio(lista)

    soma_positivos = positivos(lista)
    qtd_negativos = negativos(lista)

    print('A lista gerada aleatoriamente é: ', end='')
    for c in lista:
        print(c, end=', ')

    print()
    print(f'A soma dos números positivos da lista é {soma_positivos}.')
    print(f'A quantidade de números negativos da lista é {qtd_negativos}.')


if __name__ == '__main__':
    main()
