'''lista02_q03'''
from random import randint


def aleatorio(a, b):
    for c in range(0, b):
        a.append(randint(0, 15))

    return a


def inverter_lista(a):
    inverso = []

    for c in a:
        inverso.insert(0, c)

    return inverso


def main():
    lista = []
    lista_invertida = []
    num = int(input('Digite o número de elementos da lista: \n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    lista = aleatorio(lista, num)
    lista_invertida = inverter_lista(lista)

    print(f'A lista gerada aleatoriamente é {lista}.')
    print(f'A lista invertida é {lista_invertida}.')


if __name__ == '__main__':
    main()
