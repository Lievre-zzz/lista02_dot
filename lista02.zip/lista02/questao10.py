'''lista02_q10'''
from random import randint


def aleatorio(a):
    for c in range(0, 15):
        a.append(randint(-100, 100))

    return a


def maior_menor(a):
    maior = max(a)
    menor = min(a)
    posmaior = a.index(max(a))
    posmenor = a.index(min(a))

    return maior, menor, posmaior, posmenor


def main():
    lista = []
    lista = aleatorio(lista)

    maior, menor, posmaior, posmenor = maior_menor(lista)

    print(f'A lista gerada aleatoriamente é {lista}.')
    print(f'O maior valor dessa lista é {maior} e pode ser encontrado na posição {posmaior}.')
    print(f'O menor valor dessa lista é {menor} e pode ser encontrado na posição {posmenor}.')


if __name__ == '__main__':
    main()

