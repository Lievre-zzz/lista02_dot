def num_perfeito(a):
    divisores = 0

    for c in range(1, a):
        if a % c == 0:
            divisores += c

    if divisores == a:
        return True
    else:
        return False


def sequencia(a):
    lista = []

    for c in range(1, a):
        if num_perfeito(c) is True:
            lista.append(c)

    return lista


def main():
    num = int(input('Digite um número maior que 1: \n'))

    while num <= 1:
        num = int(input('Valor inválido! Tente novamente.\n'))

    perfeitos = sequencia(num)

    if len(perfeitos) > 0:
        print(f'Os números perfeitos que estão entre 1 e o número digitado são {perfeitos}.')
    else:
        print('Não há nenhum número perfeito entre 1 e o número digitado.')


if __name__ == '__main__':
    main()
