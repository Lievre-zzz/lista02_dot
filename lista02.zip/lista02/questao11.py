'''lista02_q11'''
from random import randint


def main():



if __name__ == '__main__':
    main()
