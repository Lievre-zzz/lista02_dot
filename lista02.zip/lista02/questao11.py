'''lista02_q11'''


def main():
    nomes = []

    while True:
        print('-=' * 30)
        print('------MENU------')
        print('1) Cadastrar nome')
        print('2) Pesquisar nome')
        print('3) Listar todos os nomes')
        print('0) Sair do programa')
        resposta = int(input('-> ').strip())

        while resposta < 0 or resposta > 3:
            resposta = int(input('Valor inválido! Tente novamente.\n-> ').strip())

        if resposta == 1:
            cadastro = input('Digite o nome que deseja cadastrar:\n-> ').strip()

            if len(nomes) > 0:
                for pos, c in enumerate(nomes):
                    if c.lower() == cadastro.lower():
                        print('O nome desejado já está cadastrado.')
                        break

                    if pos == len(nomes) - 1 and c.lower() != cadastro.lower():
                        print('Nome cadastrado com sucesso.')
                        nomes.append(cadastro)
                        break
            else:
                print('Nome cadastrado com sucesso.')
                nomes.append(cadastro)

        elif resposta == 2:
            if len(nomes) > 0:
                pesquisa = input('Digite o nome que deseja pesquisar:\n-> ').strip()

                for pos, c in enumerate(nomes):
                    if c.lower() == pesquisa.lower():
                        print(f'O nome desejado está na posição {pos} da lista (começando a contagem do 0).')
                        break

                    if pos == len(nomes) - 1 and c.lower() != pesquisa.lower():
                        print(f'O nome desejado não está na lista.')
            else:
                print('Não há nenhum nome cadastrado na lista.')

        elif resposta == 3:
            if len(nomes) > 0:
                print('Os nomes registrados na lista são: ', end='')

                for pos, c in enumerate(nomes):
                    if pos == len(nomes) - 1:
                        print(c, end='.\n')
                    else:
                        print(c, end=', ')
            else:
                print('Não há nenhum nome cadastrado na lista.')

        else:
            print('Programa finalizado com sucesso. Obrigado por usar.')
            break


if __name__ == '__main__':
    main()
