'''lista02_q08: Dada uma lista contendo letras do alfabeto, elabore um programa para verificar quantas vezes
ocorreu a letra ‘A’.'''


def main():
    lista = ['a', 'e', 'x', 'a', 'f', 'h', 's', 'a', 'a', 'y', 'm', 'h', 'a', 't', 'q', 'b', 'a', 'j', 'r', 'a', 'v',
             'b', 'a', 'p', 'a']

    print(f'A lista é {lista}.')
    print(f'A letra \'a\' aparece {lista.count("a")} vezes.')


if __name__ == '__main__':
    main()
