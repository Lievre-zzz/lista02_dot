'''lista02_q19'''
from random import randint


def aleatorio(a, b):
    for c in range(0, 5):
        a.append(randint(0, 10))

    for c in range(0, 10):
        b.append(randint(10, 50))

    return a, b


def montarlista(a, b, c):
    for cont in a:
        c.append(cont)

    for cont in b:
        c.append(cont)

    return c


def main():
    listar = []
    listas = []
    listax = []
    listar, listas = aleatorio(listar, listas)
    listax = montarlista(listar, listas, listax)

    print(f'A lista R com 5 elementos é {listar}.')
    print(f'A lista S com 10 elementos é {listas}.')
    print(f'A lista X com os 5 elementos de R seguidos pelos 10 de S é {listax}.')


if __name__ == '__main__':
    main()
