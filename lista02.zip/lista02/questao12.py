'''lista02_q12: Deseja-se publicar o número de acertos de cada aluno em uma prova em forma de testes. A
prova consta de 30 questões, cada uma com cinco alternativas identificadas por A, B, C, D e E.
Para isso são dados:
o cartão gabarito;
o número de alunos da turma;
o cartão de respostas para cada aluno, contendo o seu número e suas respostas. '''
from random import choice


def aleatorio(a, b, c, d, e, f):
    respostas = ['a', 'b', 'c', 'd', 'e']

    for cont in range(0, 30):
        a.append(choice(respostas))
        b.append(choice(respostas))
        c.append(choice(respostas))
        d.append(choice(respostas))
        e.append(choice(respostas))
        f.append(choice(respostas))

    return a, b, c, d, e, f


def notas(a, b, c, d, e, f):
    n1, n2, n3, n4, n5 = 0, 0, 0, 0, 0
    a1, a2, a3, a4, a5 = [], [], [], [], []

    for pos, cont in enumerate(f):
        if cont == a[pos]:
            n1 += 1
            a1.append(pos + 1)

        if cont == b[pos]:
            n2 += 1
            a2.append(pos + 1)

        if cont == c[pos]:
            n3 += 1
            a3.append(pos + 1)

        if cont == d[pos]:
            n4 += 1
            a4.append(pos + 1)

        if cont == e[pos]:
            n5 += 1
            a5.append(pos + 1)

    return n1, n2, n3, n4, n5, a1, a2, a3, a4, a5


def main():
    aluno1, aluno2, aluno3, aluno4, aluno5, gabarito = [], [], [], [], [], []
    aluno1, aluno2, aluno3, aluno4, aluno5, gabarito = aleatorio(aluno1, aluno2, aluno3, aluno4, aluno5, gabarito)

    nota1, nota2, nota3, nota4, nota5, acertos1, acertos2, acertos3, acertos4, acertos5 = notas(aluno1, aluno2, aluno3, aluno4, aluno5, gabarito)

    print(f'O gabarito da prova é {gabarito}.')
    print(f'O aluno 1 acertou as questões {acertos1}, totalizando {nota1} acertos.')
    print(f'O aluno 2 acertou as questões {acertos2}, totalizando {nota2} acertos.')
    print(f'O aluno 3 acertou as questões {acertos3}, totalizando {nota3} acertos.')
    print(f'O aluno 4 acertou as questões {acertos4}, totalizando {nota4} acertos.')
    print(f'O aluno 5 acertou as questões {acertos5}, totalizando {nota5} acertos.')


if __name__ == '__main__':
    main()
