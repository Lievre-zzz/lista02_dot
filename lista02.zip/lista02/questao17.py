'''lista02_q17: Ler uma lista W de 10 elementos, depois ler um valor V. Contar e escrever quantas vezes o
valor V ocorre na lista W e escrever também em que posições (índices) da lista W o valor V
aparece.'''
from random import randint


def aleatorio(a):
    for c in range(0, 10):
        a.append(randint(0, 10))

    return a


def encontrar(a, b):
    posicoes = []
    ocorrencias = 0

    for pos, c in enumerate(a):
        if c == b:
            posicoes.append(pos)
            ocorrencias += 1
        else:
            continue

    return posicoes, ocorrencias


def main():
    lista = []
    lista = aleatorio(lista)
    posicoes = []
    ocorrencias = 0

    num = int(input('Digite um número entre 0 e 10: \n'))

    while num < 0 or num > 10:
        num = int(input('Valor inválido! Tente novamente.\n'))

    posicoes, ocorrencias = encontrar(lista, num)

    print(f'A lista é {lista}.')

    if len(posicoes) == 0 and ocorrencias == 0:
        print('O número digitado não aparece nenhuma vez na lista.')
    else:
        print(f'O número digitado aparece {ocorrencias} vez(es) na lista na(s) posição(ões) {posicoes}.')


if __name__ == '__main__':
    main()
