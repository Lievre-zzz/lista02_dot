'''lista02_q05'''
from random import randint


def aleatorio(a, b):
    for c in range(0, 10):
        a.append(randint(0, 200))
        b.append(randint(201, 400))

    return a, b


def intercalar_listas(a, b):
    intercalada = []

    for c in range(0, 10):
        intercalada.append(a[c])
        intercalada.append(b[c])

    return intercalada


def main():
    lista1 = []
    lista2 = []
    lista1, lista2 = aleatorio(lista1, lista2)
    intercalada = intercalar_listas(lista1, lista2)

    print(f'A primeira lista gerada aleatoriamente é {lista1}.')
    print(f'A segunda lista gerada aleatoriamente é {lista2}.')
    print(f'A lista que intercala as duas listas é {intercalada}.')


if __name__ == '__main__':
    main()
